/*************************************
 * Lab 5 Ex4
 * Name:
 * Student No:
 * Lab Group:
 *************************************
 Warning: Make sure your code works on
 lab machine (Linux on x86)
 *************************************/

#include "my_stdio.h"
#include <stdio.h>

int my_fflush(MY_FILE *stream) {
	if (stream-> is_write == 0) {
		free(stream->read_buf);
		stream->read_buf = malloc (4096);
		stream->pointer = 0;
		stream -> available_items = 0;
		return 0;
	} else {
		if (stream -> pointer == 0) {
			return 0;
		}

		if (write(stream->fd, stream->read_buf, stream->available_items) >= 0) {
			printf("IN FFLUSH\n");
			stream->pointer = 0;
			stream -> available_items = 0;
			free(stream->read_buf);
			stream->read_buf = malloc (4096);
			return 0;
		} else {
			return MY_EOF;
		}
	}
	
}

int my_fseek(MY_FILE *stream, long offset, int whence) {
	my_fflush(stream);

	int return_value = lseek(stream->fd, offset, whence);
	if (return_value < 0) {
		return -1;
	} else {
		return return_value;
	}

}