/*************************************
 * Lab 5 Ex2
 * Name:
 * Student No:
 * Lab Group:
 *************************************
 Warning: Make sure your code works on
 lab machine (Linux on x86)
 *************************************/

#include "my_stdio.h"
#include <stdio.h>

size_t my_fread(void *ptr, size_t size, size_t nmemb, MY_FILE *stream) {

	//ssize_t count = 0;
	int ptr_offset = stream->pointer;
	int available_bytes = stream -> available_items;
	int internal_offset = 0;
	char* output_array;
	char* old_array;
	int request_size = size * nmemb;
	int leftover_bytes_to_read = request_size;
	int max_buffer_capacity = 4096;

	output_array = malloc(request_size);
	stream->is_write = 0;

	if (available_bytes < request_size) { //insufficient bytes to read so setup buffer in FILE
		if (available_bytes > 0) { 	// there are leftover bytes in buffer

			leftover_bytes_to_read = request_size - available_bytes;
			old_array = malloc(available_bytes);
			memcpy(old_array, stream->read_buf + ptr_offset, available_bytes); //copy leftover in buffer to array
			memcpy(output_array + internal_offset, old_array, available_bytes); //copy old_array into output_array
			free(old_array);
			internal_offset += available_bytes;

			if (leftover_bytes_to_read >= max_buffer_capacity) {
				if (read(stream->fd, stream->read_buf, leftover_bytes_to_read) <= 0) {
					free(output_array);
					return -1;
				}
				memcpy(output_array + internal_offset, stream->read_buf, leftover_bytes_to_read);
				memcpy(ptr, output_array, request_size);
				free(output_array);
				return nmemb;
			} 

		}
		
		int read_return = read(stream->fd, stream->read_buf, max_buffer_capacity);
		stream->pointer = 0;
		//printf("read_return: %d\n", read_return);
		if (read_return <= 0) {  //EOF or error
			return -1;
		} else {
			available_bytes = read_return; //1
		}
		
	}

	char* new_array = malloc(leftover_bytes_to_read);
	memcpy(new_array, stream->read_buf + ptr_offset, leftover_bytes_to_read);
	memcpy(output_array + internal_offset, new_array, leftover_bytes_to_read);
	free(new_array);
	
	internal_offset += leftover_bytes_to_read;
	ptr_offset += leftover_bytes_to_read; // =1
	available_bytes -= leftover_bytes_to_read;

	stream->available_items = available_bytes;
	stream->pointer = ptr_offset % max_buffer_capacity; //offset exceeds buffer size
	memcpy(ptr, output_array, request_size);
	free(output_array);
	return nmemb;
}
