/*************************************
 * Lab 5 Ex3
 * Name:
 * Student No:
 * Lab Group:
 *************************************
 Warning: Make sure your code works on
 lab machine (Linux on x86)
 *************************************/

#include "my_stdio.h"
#include <stdio.h>

size_t my_fwrite(const void *ptr, size_t size, size_t nmemb, MY_FILE *stream) {
	int ptr_offset = stream->pointer;
	int available_bytes = 4096 - stream -> available_items;
	int internal_offset = 0;
	char* old_array;
	int request_size = size * nmemb;
	int leftover_bytes_to_write = request_size;
	int max_buffer_capacity = 4096;

	stream->is_write = 1;
	

	if (available_bytes < request_size) { //insufficient bytes to write so setup buffer in FILE
		if (available_bytes > 0) {// there are available bytes in buffer
			leftover_bytes_to_write = request_size - available_bytes;
			old_array = malloc(available_bytes);
			memcpy(old_array, ptr, available_bytes); //copy ptr to array
			memcpy(stream->read_buf + ptr_offset, old_array, available_bytes); //copy old_array into stream buf
			free(old_array);
			internal_offset += available_bytes; 
			if (write(stream->fd, stream->read_buf, max_buffer_capacity) <= 0) { // write buffer to fd
				return -1;
			}
		}

		if (leftover_bytes_to_write >= max_buffer_capacity) { // write ptr to fd
			if (write(stream->fd, ptr, leftover_bytes_to_write) <= 0) {
				return -1;
			}
			return nmemb;
		} 
		// do nothing if buffer is empty
	}

	char* new_array = malloc(leftover_bytes_to_write); //new array for leftover bytes
	memcpy(new_array, ptr + internal_offset, leftover_bytes_to_write);
	memcpy(stream -> read_buf, new_array, leftover_bytes_to_write);
	free(new_array);

	ptr_offset += leftover_bytes_to_write; // =1
	available_bytes -= leftover_bytes_to_write;

	/*if (available_bytes == 0) { // if buffer is full
		if (write(stream->fd, stream -> read_buf, max_buffer_capacity) <= 0) {
			return -1;
		}
	}*/

	stream->available_items = (max_buffer_capacity - available_bytes) % max_buffer_capacity;
	stream->pointer = ptr_offset % max_buffer_capacity; //offset exceeds buffer size
	printf("available items: %d\n", available_bytes);
	printf("pointer: %d\n", ptr_offset);
	return nmemb;
}
